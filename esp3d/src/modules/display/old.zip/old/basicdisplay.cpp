/*
  basicdisplay.cpp -  display functions class

  Copyright (c) 2014 Luc Lebosse. All rights reserved.

  This code is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This code is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with This code; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "../../include/esp3d_config.h"
#if defined (DISPLAY_DEVICE) && (DISPLAY_UI_TYPE == UI_TYPE_BASIC)

#include "basicdisplay.h"
#include "../../core/settings_esp3d.h"
#include "../../core/esp3doutput.h"

#if DISPLAY_DEVICE == OLED_I2C_SSD1306 || DISPLAY_DEVICE == OLED_I2C_SSDSH1106
#include "Wire.h"
#include "esp3d_logo.h"
#if DISPLAY_DEVICE == OLED_I2C_SSD1306
#include <SSD1306Wire.h>
SSD1306Wire  esp3d_screen(DISPLAY_I2C_ADDR, ESP_SDA_PIN, ESP_SCL_PIN);
#include "basic_SSD1306.h"
#endif //DISPLAY_DEVICE == OLED_I2C_SSD1306
#if DISPLAY_DEVICE == OLED_I2C_SSDSH1106
#include <SH1106Wire.h>
SH1106Wire  esp3d_screen(DISPLAY_I2C_ADDR, ESP_SDA_PIN, ESP_SCL_PIN);
#include "basic_SSDSH1106.h"
#endif //DISPLAY_DEVICE == OLED_I2C_SSDSH1106
#endif //DISPLAY_DEVICE == OLED_I2C_SSD1306 || DISPLAY_DEVICE == OLED_I2C_SSDSH1106
#if (DISPLAY_DEVICE == TFT_SPI_ILI9341_320X240) || (DISPLAY_DEVICE == TFT_SPI_ILI9488_480X320)
#include <TFT_eSPI.h>
TFT_eSPI esp3d_screen = TFT_eSPI();
#include "esp3d_logob.h"
#if (DISPLAY_DEVICE == TFT_SPI_ILI9341_320X240)
#include "basic_ILI9341_320X240.h"
#endif //(DISPLAY_DEVICE == TFT_SPI_ILI9341_320X240)
#if (DISPLAY_DEVICE == TFT_SPI_ILI9488_480X320)
#include "basic_ILI9488_480X320.h"
#endif //(DISPLAY_DEVICE == TFT_SPI_ILI9488_480X320)
#endif //(DISPLAY_DEVICE == TFT_SPI_ILI9341_320X240) || (DISPLAY_DEVICE == TFT_SPI_ILI9488_480X320)
#if defined (WIFI_FEATURE)
#include "../wifi/wificonfig.h"
#endif // WIFI_FEATURE
#if defined (ETH_FEATURE)
#include "../ethernet/ethconfig.h"
#endif //ETH_FEATURE
#if defined (BLUETOOTH_FEATURE)
#include "../bluetooth/BT_service.h"
#endif //BLUETOOTH_FEATURE
#if defined (WIFI_FEATURE) || defined (ETH_FEATURE) || defined (BLUETOOTH_FEATURE)
#include "../network/netconfig.h"
#endif //WIFI_FEATURE || ETH_FEATURE) ||BLUETOOTH_FEATURE
#define DISPLAY_REFRESH_TIME 1000

//TODO : need to change this to a better way
//just set a bool value to enable calibration
//add check of value in handle to do the calibration
//so it won't be blocking call
bool Display::startCalibration()
{
    bool res = false;
#if defined(DISPLAY_TOUCH_DRIVER)
#if DISPLAY_TOUCH_DRIVER == XPT2046_SPI
    uint16_t calibrationData[5];
    clear_screen();
    //display instructions
    uint size = getStringWidth("Touch corners as indicated");
    setTextFont(FONTCALIBRATION);
    drawString("Touch corners as indicated", (SCREEN_WIDTH-size)/2, (SCREEN_HEIGHT-16)/2, CALIBRATION_FG);
    esp3d_screen.calibrateTouch(calibrationData, CALIBRATION_CORNER, CALIBRATION_BG, 15);
    res = true;
    for (uint8_t i = 0; i < 5; i++) {
        if(!Settings_ESP3D::write_uint32 (ESP_CALIBRATION_1+(4*i), calibrationData[i])) {
            res= false;
        }
    }
    if (!Settings_ESP3D::write_byte (ESP_CALIBRATION, 1)) {
        res= false;
    }
    clear_screen();
    if(res) {
        SetStatus("Calibration done");
    } else {
        SetStatus("Calibration error");
    }
    update_screen(true);
#endif //XPT2046_SPI 

#endif //DISPLAY_TOUCH_DRIVER
    return res;
}

Display esp3d_display;























#endif //DISPLAY_DEVICE
